#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.from com.anuta.driversdk.driver import BasicDeviceDriver
from ncxparser import util
class Sdk:
    _instance = None

    def __init__(self):
        from com.anuta.util import ApplicationContextProvider
        ctx = ApplicationContextProvider.getApplicationContext()
        from com.anuta.parserapi.service import NaasConfigParserManager
        self.parserSvc = ctx.getBean(NaasConfigParserManager)
        from com.anuta.agent.device import DeviceConfigParsingService
        self.configParsingSvc = ctx.getBean(DeviceConfigParsingService)

    @staticmethod
    def getInstance():
        if(Sdk._instance == None):
            Sdk._instance = Sdk()
        return Sdk._instance


def register_config_provider(platform, provider):
    util.log_info('Registering %s' % (provider) )
    Sdk.getInstance().parserSvc.registerPlatformDecoderProvider(platform, provider)

def unregister_config_provider(platform):
    util.log_info('Unregistering %s' % (platform) )
    Sdk.getInstance().parserSvc.unregisterPlatformDecoderProvider(platform)

from com.anuta.parserapi.api.service.context import ParserConfigProvider
from com.anuta.parserapi.api.service.context import ConfigResultProcessor
from com.anuta.parserapi.api.service import CandidateTreeSelector
from com.anuta.parserapi.api.service.context import VariableDecoder
from com.anuta.agent.device import DeviceConfigParser
from com.anuta.yang.base.data import DevicePlatformMap
class DefaultVariableDecoder(VariableDecoder):
    def __init__(self):
        pass

    def decodeVariables(self, parserContext, decoderContext, variableDecoderContext):
        pass

class DefaultResultProcessor(ConfigResultProcessor):
    def processResults(self, results):
        pass

    def processResultsAfterMerge(self, entities):
        pass

class DefaultTreeSelector(CandidateTreeSelector):
    def identifyCandidateTree(self, tsc):
        pass

class DevicePlatformMap(DevicePlatformMap):

    def __init__(self):
        pass

    def get(self, platform):
        super(DevicePlatformMap, self).get(platform)


class AbstractParserConfigProvider(ParserConfigProvider):
    def __init__(self, platform):
        self.decoderMap = DevicePlatformMap().get(platform)
        self.variableDecoderMap = DevicePlatformMap().get(platform)
        self.result_processor = None
        self.block_parser = None
        self.tree_selector = None
        pass


    def set_result_processor(self, platform):
        result_proxy = Sdk.getInstance().parserSvc.makeProxyResultProcessor(platform)
        self.result_processor = result_proxy

    def set_block_parser(self, platform):
        block_proxy = Sdk.getInstance().parserSvc.makeProxyBlockParser(platform)
        self.block_parser = block_proxy

    def set_tree_selector(self, platform):
        tree_sel_proxy = Sdk.getInstance().parserSvc.makeProxyCandidateTreeSelector(platform)
        self.tree_selector = tree_sel_proxy

    def get_result_processor(self):
        return self.result_processor

    def get_block_parser(self, platform):
        return self.block_parser

    def get_tree_selector(self, platform):
        return self.tree_selector

    def detach(self):
        self.result_processor_proxy.detach()
        self.block_parser_proxy.detach()
        self.tree_selector_proxy.detach()

    def getTokenDecoder(self, configParserContext, devicePlatform, fullVariablePath):
        try:
            if self.decoderMap is not None:
                decoder = self.decoderMap.get(fullVariablePath.getPath())
                util.log_info ('The decoder = %s Full Variable Path = %s' %(decoder,fullVariablePath.getPath()))
                return decoder
            return None
        except Exception:
            traceback.print_exc()

    def getVariableDecoder(self, configParserContext, devicePlatform, fullVariablePath):
        try:
            print 'CALLING Variable TokenDecoder'
            print 'Full Variable Path = %s' %(fullVariablePath.getPath())
            if self.variableDecoderMap is not None:
                decoder = self.variableDecoderMap.get(fullVariablePath.getPath())
                util.log_info ('The decoder = %s Full Variable Path = %s' %(decoder,fullVariablePath.getPath()))
                return decoder
            return None
        except Exception:
            traceback.print_exc()

    def getConfigResultProcessor(self):
        return self.result_processor

    def getCandidateTreeSelector(self):
        return self.tree_selector

    def parseConfig(self, input):
        return self.block_parser.parseConfig(input)

    def parseConfig(self, reader):
        return self.block_parser.parseConfig(reader)


class AbstractDeviceConfigParser(DeviceConfigParser):
    def __init__(self):
        pass

    def processConfigParsing(self):
        pass


