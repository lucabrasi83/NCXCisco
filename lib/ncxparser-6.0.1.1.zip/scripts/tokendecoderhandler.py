#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import util
class TokenDecoderHandler():
    """
    Handles the commands obtained from the device, decode the variables and adds the value to the relevant field.
    Tokens refers to the words present in a line of command. 
    """
    def __init__(self, decoderContext):
       self.decoderContext = decoderContext

    def getSearchTokens(self):
        """
        Fetches the line from the command and converts it to tokens.

            Args:
                Line of command.

            Returns:
                Tokens (words) in the line of command.
                Data Type: List.
        """
        return self.decoderContext.getSearchTokens()

    def getSearchTokensSize(self):
        """
        Fetches the line from the command and returns the number of tokens present in it.

            Args:
                Line of command.

            Returns:
                Number of Tokens (words) present in the line of command.
                Data Type: int
        """
        return self.decoderContext.getSearchTokens().size()

    def getValueAtGivenIndex(self, index):
        searchTokens = self.decoderContext.getSearchTokens()
        return searchTokens.get(index)

    def getToken(self):
        """
        Fetches the name of a particular token from the path mentioned by the token decoder.

            Args:
                Path of command referred by the token decoder.

            Returns:
                Name of the token that is referred in the path by token dcoder.
        """
        return self.decoderContext.getToken()

    def setToken(self, token):
        util.log_debug('The token to set here is = %s' %(token))
        self.decoderContext.setToken(token)

    def setCurrentIndex(self, curIndex):
        self.decoderContext.setCurrentIndex(curIndex)

    def getTokenText(self):
        #print 'The decodercontext = %s' %(self.decoderContext)
        """
        Fetches the name of a particular token from the path mentioned by the token decoder.

            Args:
                Path of command referred by the token decoder.

            Returns:
                Name of the token that is referred in the path by token dcoder.
        """
        return self.decoderContext.getToken().getText()

    def getValueAtCurrentIndex(self):
        """
        Fetches the value at the current position of the cursor/index.

            Args:
                Line of command

            Returns:
                The value of the token at the current position of the cursor/index.
                Data Type: String
        """
        searchTokens = self.decoderContext.getSearchTokens()
        return searchTokens.get(self.decoderContext.getCurrentIndex())

    def getCurrentBlockTokens(self):
        """
        Fetches the block of command that is currently referred to and converts it to tokens.

            Args:
                Block of command.

            Returns:
                Tokens (words) in the line of command.
                Data Type: List.
        """
        return self.decoderContext.getCurrentBlock().getTokens()

    def isValidInteger(self, lineNum):
        return lineNum.isnumeric()

    def getCurrentBlock(self):
        """
        Fetches the block of command that is currently referred to.

            Args:
                Block of command.

            Returns:
                Block of command.
                Data Type: String.
        """
        return self.decoderContext.getCurrentBlock()

    def getCurrentBlockTokens(self):
        return self.decoderContext.getCurrentBlock().getTokens()

    def getSearchTokensIncludingSpaces(self):
        """
        Fetches the line of command including spaces.

            Args:
                Line of command.

            Returns:
                List of tokens including spaces between them.
                Data Type: List.
        """
        return self.decoderContext.getSearchTokensIncludingSpaces()

    def getCurrentIndex(self):
        """
        Fetches the current position of the cursor.

            Args:
                Line of command

            Returns:
                The position of the index pointing to the token currently.
                Data Type: int
        """
        return self.decoderContext.getCurrentIndex()

    def getConfigParserContext(self):
        return self.decoderContext.getConfigParserContext()

    def setMark(self):
        return self.decoderContext.getConfigParserContext().setMark()

    def resetMark(self, index):
        return self.decoderContext.getConfigParserContext().resetMark(index)

    def getNextBlock(self):
        """
        Fetches the line of command next to the currently referred line.

            Args:
                Line of command.

            Returns:
                Line of command next to the current line.
                Data Type: String.
        """
        return self.decoderContext.getConfigParserContext().getNextBlock()

    def setNextTokenIndex(self,index):
        return self.decoderContext.getConfigParserContext().setNextTokenIndex(index)

    def addTokenValue(self, name,value):
        """
        Adds the value obtained from the command tokens to the variable.

            Args:
                1. Label of the variable.
                2. Value obtained from the token.

            Result:
                Values from the command tokens are assigned to the variables.
        """
        return self.decoderContext.addTokenValue(name, value)
