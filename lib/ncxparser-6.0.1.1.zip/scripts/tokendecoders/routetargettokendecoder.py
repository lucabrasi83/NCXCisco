#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import tokendecoderhandler, parser, util
from ncxparser import tokendecoder
import traceback

class RouteTargetTokenDecoder(tokendecoder.AbstractTokenDecoder):

    def decodeToken(self, decoderContext):
        try:
            util.log_info('RouteTargetTokenDecoder decode token')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            tokenText = decoderhandler.getTokenText()
            #b1 = parser.Sdk.getInstance().configBlock
            done = False
            decoderhandler.setMark(decoderContext)
            b1 = decoderhandler.getNextBlock()
            while  done == True and b1 is not None:
                for tok in  b1.getTokens():
                    if not util.TokenDecoderUtil.isMatchingTokenFound("\\d+:\\d+", tok):
                        done = True
                        break
                    decoderhandler.addTokenValue(tokenText, tok)
            decoderhandler.resetMark(1)
            decoderhandler.setNextTokenIndex(0)
            return 0
        except Exception:
            traceback.print_exc()

    def matchToken(self, cpc, configToken, idx, toks):
        return toks.size() - idx

    def isMultilineDecoder(self):
        return True