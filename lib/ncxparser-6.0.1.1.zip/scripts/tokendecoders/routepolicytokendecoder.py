#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import tokendecoderhandler, parser, util
import traceback

import greedytokendecoder

class RoutePolicyTokenDecoder(greedytokendecoder.GreedyTokenDecoder):

    def __init__(self, policyParameterName):
        greedytokendecoder.GreedyTokenDecoder.__init__(self)
        util.log_info('Initializing  RoutePolicyTokenDecoder with policyparam: = %s' %(policyParameterName))
        self.policyParameterName = policyParameterName

    def decodeToken(self, decoderContext):
        try:
            util.log_info('RoutePolicyTokenDecoder decode token')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            tokenText = decoderhandler.getTokenText()
            searchTokens = decoderhandler.getSearchTokens()
            name = decoderhandler.getValueAtCurrentIndex()
            idx = decoderhandler.getCurrentIndex()
            i = name.find('(')
            if i > 0:
                name = name[0,i].rstrip()
            decoderhandler.addTokenValue(tokenText, name)
            policyBuf = util.join_tokens(searchTokens, idx)
            b1 = decoderhandler.getNextBlock()
            while b1 != None:
                if b1.getTokens() is not None and "end-policy" == b1.getTokens().get(0):
                    break
                policyBuf = '%s\n' % (policyBuf)
                policyBuf = '%s%s' % (policyBuf, util.join_tokens(b1.getTokens()))

            decoderhandler.setNextTokenIndex(0)
            util.log_debug('The policy Buffer = %s'%(policyBuf))
            #log('Route-policy: %s' %(policyBuf))
            decoderhandler.addTokenValue(self.policyParameterName, policyBuf)
            return 0
        except Exception:
            traceback.print_exc()


    def isMultilineDecoder(self):
        return True
