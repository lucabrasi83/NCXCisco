#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import tokendecoderhandler, tokendecoder, decoderutil, util
import traceback
class GreedyTokenDecoder(tokendecoder.AbstractTokenDecoder):
    def __init__(self, limit = -1, includespaces = False):
        util.log_debug('Initializing  GreedyTokenDecoder with limit param')
        self.limit = limit
        self.includespaces = includespaces

    def decodeToken(self, decoderContext):
        try:
            util.log_debug('GreedyTokenDecoder: Decode token NewlyImplemented')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            if self.includespaces and decoderhandler.getCurrentBlock().isRawTokensSupported():
                tokenText = decoderhandler.getTokenText()
                util.log_debug('TokenText under decodeToken method is %s' %tokenText)
                util.log_info('Enter into collectTextIncludingSpaces method')
                value = self.collectTextIncludingSpaces(decoderContext)
                util.log_info('Value from collectTextIncludingSpaces is %s' %value)
                decoderhandler.addTokenValue(tokenText, value)
                return self.getEndIndex(decoderhandler.getCurrentIndex(), decoderhandler.getSearchTokens())
            return self.decodeTokenOld(decoderContext)
        except Exception:
            traceback.print_exc()


    def collectTextIncludingSpaces(self, decoderContext):
        util.log_info('start execution of collectTextIncludingSpaces method')
        decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
        searchTokens = decoderhandler.getSearchTokensIncludingSpaces()
        util.log_debug('current searchtoken with in collectTextIncludingSpaces %s' %searchTokens)
        buf = ''
        end = 0
        idx = decoderutil.DecoderUtil.getIndexSkippingSpaces(decoderContext, decoderhandler.getCurrentIndex())
        util.log_debug('idx from collectTextIncludingSpaces is %s' %idx)
        if idx < 0:
            util.log_error('error seen during collectingText')
            return buf
        if self.limit <= 0:
            end = searchTokens.size()
            util.log_debug('if limit lessthan 0, end index is %s' %end)
        else:
            end = decoderutil.DecoderUtil.getIndexSkippingSpaces(decoderContext, decoderhandler.getCurrentIndex() + self.limit)
            util.log_debug('Under else block: end index is %s' %end)
            if end < 0:
                end = searchTokens.size()
                util.log_debug('if end lessthan 0, end index is %s' %end)
        for i in range(idx + 1, end):
            util.log_debug('searchtoken with in for-loop for idx %s' %searchTokens.get(idx))
            util.log_debug('searchtoken with in for-loop for i  %s' %searchTokens.get(i))
            buf = buf + searchTokens.get(i)
            util.log_debug('buffer text within forloop %s' %buf)
        if len(buf) > 0 and buf[-1:] == '\n':
            buf = buf[:-1]
            util.log_debug('buffer text within new-line %s' %buf)
        if len(buf) > 0 and buf[-1:] == '\r':
            buf = buf[:-1]
            util.log_debug('buffer text within carriage-return %s' %buf)
        util.log_debug('buffer text within collectTextIncludingSpaces is %s' %buf)
        return buf

    def decodeTokenOld(self, decoderContext):
        try:
            util.log_info('GreedyTokenDecoder: Enter into decodeTokenOld method')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            tokenText = decoderhandler.getTokenText()
            util.log_debug('Token text with in decodeTokenOld is %s'%tokenText)
            searchTokens = decoderhandler.getSearchTokens()
            util.log_debug('Search Tokens %s'%searchTokens)
            end = self.getEndIndex(decoderhandler.getCurrentIndex(), searchTokens)
            util.log_debug('Value of end with in decodeTokenOld is %s'%end)
            count = 0
            buffer = ''
            util.log_debug('CurrentIndex with in decodeTokenOld is %s' %decoderhandler.getCurrentIndex())
            for i in range(decoderhandler.getCurrentIndex(), end):
                if count > 0:
                    buffer = buffer + ' '

                util.log_debug('current searchtoken with in decodeTokenOld  %s' %searchTokens.get(i))
                buffer = buffer + searchTokens.get(i)
                count += 1
            util.log_info('Final Buffer after execution of decodeTokenOld is %s' %buffer)
            decoderhandler.addTokenValue(tokenText, buffer)
            util.log_debug('count after execution of decodeTokenOld is %s' %count)
            return count
        except Exception:
            traceback.print_exc()


    def getEndIndex(self, curIdx, tokens):
        try:
            end = 0
            if self.limit <= 0:
                util.log_debug('Tokens size under getEndIndex is %s' %tokens.size())
                end = tokens.size()
            else:
                end = curIdx + self.limit
            util.log_debug('End val under getEndIndex is %s' %end)
            return end
        except Exception:
            traceback.print_exc()


    def matchToken(self, configParserContext, configToken, idx, toks):
        return self.getEndIndex(idx, toks) - idx
    
    def includespaces(self):
        self.includespaces = True
        return self


    def isMultilineDecoder(self):
        return False


