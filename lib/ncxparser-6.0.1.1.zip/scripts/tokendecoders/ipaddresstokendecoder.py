#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import tokendecoder
from ncxparser import tokendecoderhandler, parser, util
import traceback

class IpAddressTokenDecoder(tokendecoder.AbstractTokenDecoder):

    def __init__(self, ipV4Address):
        util.log_info('Initializing IpaddressTokenDecoder')
        self.ipV4Address = ipV4Address

    def decodeToken(self, decoderContext):
        try:
            util.log_info('decodetoken in IpAddressTokenDecoder')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            tokenText = decoderhandler.getTokenText()
            value = decoderhandler.getValueAtCurrentIndex()
            if self.ipV4Address and not(util.is_ipv4_address(value)):
                return 0
            elif not(self.ipV4Address) and not(util.is_ipv6_address(value)):
                return 0
            decoderhandler.addTokenValue(tokenText, value)
            return 1
        except Exception:
            traceback.print_exc()

    def matchToken(self, configParserContext, configToken, idx, toks):
        value = toks.get(idx)
        if self.ipV4Address and  not(util.is_ipv4_address(value)):
            return -1
        elif not(self.ipV4Address) and not(util.is_ipv6_address(value)):
            return -1
        return 1


    def isMultilineDecoder(self):
        return False


