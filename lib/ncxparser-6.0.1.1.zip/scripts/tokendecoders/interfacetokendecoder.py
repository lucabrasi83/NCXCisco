#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.


from org.apache.http.conn.util import InetAddressUtils
from ncxparser import tokendecoderhandler
from ncxparser import tokendecoder, util
import traceback

class InterfaceTokenDecoder(tokendecoder.AbstractTokenDecoder):

    def decodeToken(self, decoderContext):
        try:
            util.log_info('InterfaceTokenDecoder: Decode token')
            decoderhandler = tokendecoderhandler.TokenDecoderHandler(decoderContext)
            tokenText = decoderhandler.getTokenText()
            util.log_debug('Token text = %s' %(tokenText))
            value = decoderhandler.getValueAtCurrentIndex()
            if not InetAddressUtils.isIPv4Address(value):
                return 0
            util.log_debug('The value is = %s' %(value))
            decoderhandler.addTokenValue(tokenText, value)
            return 1
        except Exception:
            traceback.print_exc()

    def matchToken(self, configParserContext, configToken, idx, toks):
        return 1


    def isMultilineDecoder(self):
        return False


