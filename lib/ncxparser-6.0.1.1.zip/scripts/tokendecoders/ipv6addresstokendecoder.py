#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

from ncxparser import tokendecoderhandler, parser, util
from ncxparser import tokendecoder

class Ipv6AddressTokenDecoder(tokendecoder.AbstractTokenDecoder):

    def __init__(self,addressTokenName,prefixTokenName):
        self.addressTokenName = addressTokenName
        self.prefixTokenName = prefixTokenName

    def decodeToken(self, ctx):
        decoderhandler = tokendecoderhandler.TokenDecoderHandler(ctx)
        value = decoderhandler.getValueAtCurrentIndex()
        network = None
        masklen = None
        if self.isEuiAddress(ctx):
            return 0
        idx = value.find('/')
        if idx > 0:
            try:
                ipaddr = value[0:idx]
                masklen = value[idx + 1:]
                inetaddr = util.forString(ipaddr)
                network = inetaddr.getHostAddress()
            except:
                network = value

        tokenName = decoderhandler.getTokenText()
        iPv6Address = parser.Sdk.getInstance().ipv6Address.fromString(network)
        #Need to change python way
        network = str(iPv6Address)
        decoderhandler.addTokenValue(tokenName, network)
        if masklen is not None:
            maskLenName = None
            if "/" in tokenName:
                maskLenName = tokenName.rsplit('/', 1)[0]+ self.prefixTokenName
            else:
                maskLenName = "$" + self.prefixTokenName
            util.log_debug('tokenName = %s, maskLenName = %s,  value = %s, network = %s, masklen = %s' %(tokenName,maskLenName, value, network, masklen))
            decoderhandler.addTokenValue(maskLenName, masklen)
        else:
            util.log_debug('tokenName = %s, value = %s, network = %s, masklen = %s' %(tokenName, value, network, masklen))
        return 1



    def isEuiAddress(self, ctx):
        decoderhandler = tokendecoderhandler.TokenDecoderHandler(ctx)
        tokenIdx =  decoderhandler.getCurrentIndex() + 1
        if tokenIdx < decoderhandler.getSearchTokensSize():
            nextToken = decoderhandler.getSearchTokens().get(tokenIdx)
            if nextToken == "eui-64" :
                return True

        return False


    def matchToken(self, configParserContext, configToken, idx, toks):
        return 1


    def isMultilineDecoder(self):
        return False


