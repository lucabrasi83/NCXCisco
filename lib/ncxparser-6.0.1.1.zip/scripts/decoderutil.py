#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.


from ncxparser.tokendecoders import dummytokendecoder, ipaddresstokendecoder, ipv6addresstokendecoder
from ncxparser import parser, util
from ncxparser import tokendecoderhandler
class DecoderUtil():
    def __init__(self):
        pass

    @staticmethod
    def initCommanDecoders(decoderMap):
        decoderMap['/controller:devices/device/interface:interfaces/interface/ipv6-address'] = ipv6addresstokendecoder.Ipv6AddressTokenDecoder('ipv6-address', 'ipv6-prefix-length')
        decoderMap['/controller:devices/device/interface:interfaces/interface/additional-ipv6-address/address/ip'] = ipv6addresstokendecoder.Ipv6AddressTokenDecoder('ip', 'prefix-length')
        decoderMap['/controller:devices/device/interface:interfaces/interface/ipv6-prefix-length'] = dummytokendecoder.DummyTokenDecoder()
        decoderMap['/controller:devices/device/interface:interfaces/interface/additional-ipv6-address/address/prefix-length'] = dummytokendecoder.DummyTokenDecoder()
        decoderMap['/controller:devices/device/l3features:vrfs/vrf/router-bgp/group/neighbor/ip-address'] = ipaddresstokendecoder.IpAddressTokenDecoder(True)
        decoderMap['/controller:devices/device/l3features:vrfs/vrf/router-bgp/group/neighbor-ipv6/ipv6-address'] = ipaddresstokendecoder.IpAddressTokenDecoder(False)

    @staticmethod
    def makeSiblingToken(token,name):
        util.log_debug( 'The Token in makesiblingtoken: = %s' %(name))
        idx = token.find('/')
        if idx < 0:
            util.log_debug('The sibling token: = %s' %(name))
            return '$' + name
        return token.rsplit('/', 1)[0] + '/' + name

    @staticmethod
    def setDefaultValue(e, name, defaultValue):
        curValue = e.getLeafValue(name)
        if curValue is None:
            e.removeLeaf(curValue)
            e.put(name, defaultValue)

    @staticmethod
    def getIndexSkippingSpaces(dc, idx):
        decoderhandler = tokendecoderhandler.TokenDecoderHandler(dc)
        tokenIndex = 0
        for i in range(0, decoderhandler.getSearchTokensIncludingSpaces().size()):
            tok = decoderhandler.getSearchTokensIncludingSpaces().get(i)
            if tok is None:
                continue
            if tokenIndex == idx:
                return i
            tokenIndex = tokenIndex + 1
        return -1

    @staticmethod
    def registerCustomVariableDecoder(platform, target, decoder):
        parser.Sdk.getInstance().tokenDecoderService.registerCustomVariableDecoder(platform, target, decoder)



