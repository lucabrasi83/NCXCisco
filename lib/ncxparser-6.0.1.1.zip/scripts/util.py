#
# This computer program is the confidential information and proprietary trade
# secret of Anuta Networks, Inc. Possessions and use of this program must
# conform strictly to the license agreement between the user and
# Anuta Networks, Inc., and receipt or possession does not convey any rights
# to divulge, reproduce, or allow others to use this program without specific
# written authorization of Anuta Networks, Inc.
#
# Copyright (c) 2014-2015 Anuta Networks, Inc. All Rights Reserved.

import parser

def is_ipv4_address(input):
    from org.apache.http.conn.util import InetAddressUtils
    return InetAddressUtils.isIPv4Address(input)

def is_ipv6_address(input):
    from org.apache.http.conn.util import InetAddressUtils
    return InetAddressUtils.isIPv6Address(input)

def forString(ipasstring):
    from com.google.common.net import InetAddresses
    return InetAddresses.forString(ipasstring)

def get_running_config(device_id):
    log_info('INSIDE GETRUNNING CONFIG' )
    log_info('DeviceId = %s' % (device_id))
    parser.Sdk.getInstance().configParsingSvc.getRunningConfig(device_id)

def convert_to_parsed_entities(entity):
    return parser.Sdk.getInstance().configParsingSvc.convertToParsedEntities(entity)

def send_parser_response(ctx, pelist):
    parser.Sdk.getInstance().configParsingSvc.sendParserResponse(ctx, pelist)

def AbstractParserProvider(ConfigParserProvider):
    def __init__(self):
        self.decodermap = {}
        self.init_decoder_map()

    def getTokenDecoder(self, xpath):
        return self.decodermap[xpath]

class YangPathMap():
    def __init__(self):
        self.leaves = {}
        self.map = {}

    def put(self, key, value):
        self.map.put(key, value)
        lastToken = key.getLastToken()
        if lastToken != None:
            self.leaves.add(lastToken)

    def get(self, key):
        lastToken = key.getLastToken()
        if lastToken == None:
            return self.map.get(key)
        if self.leaves[lastToken] == None:
            return
        return self.map.get(key)

class TokenDecoderUtil():
    def getMatchingToken(self, regex, name):
        from java.util.regex import Pattern
        pattern = Pattern.compile(regex)
        matcher = Pattern.matcher(name)
        if (matcher.find()):
            return matcher.group(1)
        return None

    def isMatchingTokenFound(self, regex, token):
        from java.util.regex import Pattern
        pattern = Pattern.compile(regex)
        return pattern.matcher(token).matches()

from com.anuta.parserapi.service.impl import ConfigToken
from com.anuta.parserapi.service.impl import ConfigTokenType

class ConfigTokenImpl(ConfigToken):
    def __init__(self, t = None):
        self.token_type = None
        self.token_text = None
        if t is not None:
            self.token_type = t

    def getText(self):
        return self.token_text

    def set_text(self, text):
        self.token_text = text

    def get_token_type(self):
        return self.token_type

    @staticmethod
    def new_text_token(txt):
        token = ConfigTokenImpl(ConfigTokenType.TEXT)
        token.set_text(txt)
        return token

    @staticmethod
    def new_variable_token(name):
        token = ConfigTokenImpl(ConfigTokenType.VARIABLE)
        token.set_text(name)
        return token


class TokenCursor():
    def __init__(self, tokens = None, curIdx = -1, decoderContext = None):
        log_debug('Token cursor tokens = %s' %(tokens) )
        log_debug( 'Token cursor curids = %s' %(curIdx) )
        self.tokens = tokens
        self.curIdx = curIdx
        if(decoderContext is not None):
            self.tokens = decoderContext.getSearchTokens()
            self.curIdx = decoderContext.getCurrentIndex()
        
    def advance(self):
        self.curIdx += 1
        
    def hasNext(self):
        if self.curIdx >= self.tokens.size():
            return 0
        return 1

    def getNextToken(self, offset = 0):
        idx = self.curIdx + offset
        if idx < 0 or idx >= self.tokens.size():
            return None
        return self.tokens.get(idx)

    def getLastToken(self):
        return self.tokens.get(self.tokens.size() - 1)

    def isLast(self):
        if self.curIdx == self.tokens.size() - 1:
            return 1
        return 0

def isIpAddress(value):
    from java.util.regex import Pattern
    return Pattern.compile("\\d+\\.\\d+\\.\\d+\\.\\d+").matcher(value).matches()


def join_tokens(search_tokens, from_idx = 0, count = -1):
    buf = ''
    if count < 0:
        end_idx = search_tokens.size()
    else:
        end_idx = from_idx + count
    for i in range(from_idx, end_idx):
        if i == idx:
            buf = '%s%s' % (buf, search_tokens.get(i))
        else:
            buf = '%s %s' % (buf, search_tokens.get(i))
    return buf


def safe_get(search_tokens, idx):
    if idx < search_tokens.size():
        return search_tokens.get(idx)
    return None

try:
    from com.anuta.python import LogWriter
except ImportError:
    pass


LOG_LEVEL_DEBUG = 1
LOG_LEVEL_INFO = 2
LOG_LEVEL_ERROR = 3

DEFAULT_LOG_LEVEL = LOG_LEVEL_INFO

def get_defatul_log_level():
    return DEFAULT_LOG_LEVEL

def set_defatul_log_level(level):
    DEFAULT_LOG_LEVEL = level

def log_debug(*x):
    if get_defatul_log_level() <= LOG_LEVEL_DEBUG:
        buf = ''
        for v in x:
            buf = '%s %s' % (buf, v)
        try:
            LogWriter.log_debug(buf)
        except NameError:
            pass

def log_error(*x):
    if get_defatul_log_level() <= LOG_LEVEL_ERROR:
        buf = ''
        for v in x:
            buf = '%s %s' % (buf, v)
        try:
            LogWriter.log_error(buf)
        except NameError:
            pass

def log_info(*x):
    if get_defatul_log_level() <= LOG_LEVEL_INFO:
        buf = ''
        for v in x:
            buf = '%s %s' % (buf, v)
        try:
            LogWriter.log_error(buf)
        except NameError:
            pass